"""
API routes package.
"""

from api.server.routes import scoring, analysis, config

__all__ = ["scoring", "analysis", "config"]
