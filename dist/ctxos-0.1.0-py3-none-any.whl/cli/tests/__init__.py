"""
CLI module tests package.
"""

__all__ = ["test_cli"]
