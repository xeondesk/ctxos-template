def add_command(subparsers):
    print('Risk command ready')
