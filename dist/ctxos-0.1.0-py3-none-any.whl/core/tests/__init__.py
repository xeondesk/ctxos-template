"""
Core module tests.
"""
