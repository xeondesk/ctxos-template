"""
Core utilities for CtxOS.
"""

from .dict_utils import (
    generate_hash,
    merge_dicts,
    flatten_dict,
    unflatten_dict,
    sanitize_dict,
    filter_by_keys,
    get_nested,
    set_nested,
    convert_timestamps,
    sort_dict,
    compact_dict,
    diff_dicts,
    json_encode,
    json_decode,
)

from .string_utils import (
    is_valid_domain,
    is_valid_ip,
    is_valid_ipv6,
    is_valid_email,
    is_valid_url,
    is_valid_uuid,
    is_valid_cidr,
    normalize_domain,
    normalize_email,
    extract_domain,
    extract_domains,
    extract_emails,
    extract_ips,
    extract_urls,
    truncate,
    slugify,
    camel_to_snake,
    snake_to_camel,
)

__all__ = [
    # dict_utils
    "generate_hash",
    "merge_dicts",
    "flatten_dict",
    "unflatten_dict",
    "sanitize_dict",
    "filter_by_keys",
    "get_nested",
    "set_nested",
    "convert_timestamps",
    "sort_dict",
    "compact_dict",
    "diff_dicts",
    "json_encode",
    "json_decode",
    # string_utils
    "is_valid_domain",
    "is_valid_ip",
    "is_valid_ipv6",
    "is_valid_email",
    "is_valid_url",
    "is_valid_uuid",
    "is_valid_cidr",
    "normalize_domain",
    "normalize_email",
    "extract_domain",
    "extract_domains",
    "extract_emails",
    "extract_ips",
    "extract_urls",
    "truncate",
    "slugify",
    "camel_to_snake",
    "snake_to_camel",
]

