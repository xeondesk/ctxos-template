class BaseAgent:
    def run(self):
        print('Running agent...')
