class BaseCollector:
    def collect(self, target):
        print(f'Collecting signals from {target}')
        return []
