def demo_graph():
    print('Graph engine running demo graph')
